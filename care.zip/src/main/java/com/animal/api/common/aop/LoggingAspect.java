package com.animal.api.common.aop;

public class LoggingAspect {

}
