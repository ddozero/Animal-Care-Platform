package com.animal.api.common.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ViewController {

}
